#pragma once

#include "../nfc_cli_dump_common_types.h"

NfcCommand nfc_cli_dump_poller_callback_iso14443_3a(NfcGenericEvent event, void* context);
